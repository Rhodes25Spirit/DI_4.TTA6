from employee import Employee

emp1 = Employee("John", "Smith", 30, "Developer", 30000)
emp2 = Employee("Lea", "Cohen", 40, "Manager", 32000)

print(emp1 > emp2) # call __gt__ method 
# then call the __str__ method
# Lea Cohen - age : 40 - job : Manager - salary : 32000

print(emp1 + emp2) # call __add__ method 
# 62000

print(emp1) #call the __str__ method
# John Smith - age : 30 - job : Developer - salary : 30000