class Employee :
    def __init__(self, fname, lname, age, job, salary):
        self.firstname = fname
        self.lastname = lname
        self.age = age
        self.job = job
        self.salary = salary

    def get_fullname(self) :
        return f"{self.firstname} {self.lastname}"
    
    def happy_birthday(self) :
        self.age += 1

    def get_promotion(self, promotion_amount):
        self.salary += promotion_amount
    
    def __str__(self) :
        return f"{self.get_fullname()} - age : {self.age} - job : {self.job} - salary : {self.salary}"

    def __gt__(self, other_employee) :
        if self.salary > other_employee.salary :
            return self
        else :
            return other_employee
        
    def __add__(self, other_employee) :
        return self.salary + other_employee.salary
