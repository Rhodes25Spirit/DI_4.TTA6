class Dog :
    # class attributes
    dog_park = "Tlv park"
    amount_dogs = 0
    all_dogs = []

    # instance attribute
    def __init__(self, name, age, type) :
        self.name = name
        self.age = age
        self.type = type
        Dog.amount_dogs += 1
        Dog.all_dogs.append(self) #self is the object
        # append the whole object

    @classmethod
    def create_new_dog(cls, name, age, type) :
        print("CLS :", cls)
        return cls(name, age, type) #Dog(name, age, type)

# using class attributes
print(Dog.amount_dogs)
print(Dog.all_dogs)

print(Dog.dog_park) #retrieve the class attribute

my_other_dog = Dog("Lola", 2, "Chihuahua")
print(my_other_dog.dog_park)


new_dog = Dog.create_new_dog("Rex", 2, "Labrador")
print(new_dog.__dict__)

print("AMOUNT OF DOGS FROM DOG CLASS :", Dog.amount_dogs)
print("ALL DOGS FROM DOG CLASS :",Dog.all_dogs)

my_dog = Dog("Rex", 2, "Labrador") # self is my_dog

print("AMOUNT OF DOGS FROM DOG CLASS :", Dog.amount_dogs)
print("ALL DOGS FROM DOG CLASS :",Dog.all_dogs)
print("AMOUNT OF DOGS FROM MY DOG OBJECT :", my_dog.amount_dogs)

print(my_dog.dog_park)
print(my_other_dog.dog_park)

my_dog.dog_park = "Ramat Gan Park"

print(my_dog.dog_park) #changed
print(my_other_dog.dog_park) #not changed

print(my_dog.dog_park)
print(my_other_dog.dog_park)

Dog.dog_park = "Ramat Gan Park"

print(my_dog.dog_park) #changed
print(my_other_dog.dog_park) #changed