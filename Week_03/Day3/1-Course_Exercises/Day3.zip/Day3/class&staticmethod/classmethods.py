class Dog :
   
    # class attribute    
    amount_dogs = 0
    all_dogs = []

    # instance attribute
    def __init__(self, name, age, type) :
        self.name = name
        self.age = age
        self.type = type
        Dog.amount_dogs += 1
        Dog.all_dogs.append(self.name)

    @classmethod #decorator
    # cls represents the class we are using to call this method
    def create_new_dog(cls, name, age, type) :
        if name in cls.all_dogs:
            return
        else :
            return cls(name, age, type)
        
    @classmethod #decorator
    def create_new_puppy(cls, name, age, type) :
        if age == 0:
            new_puppy = cls(name, age, type)
            new_puppy.favorite_food = "milk"
            return new_puppy
        else :
            print("not a puppy")
            return cls.create_new_dog(name, age, type)
    
class GermanShepard(Dog) :
    def __init__(self, name, age, type) :
        super().__init__(name, age, type)

# new_dog = GermanShepard.create_new_dog("Lola", 3, "GermanShepard")
# print(type(new_dog))
# print(new_dog.__dict__)
# new_dog_2 = Dog.create_new_dog("Lola", 3, "Labrador")

# nwe_german_shepard = GermanShepard("Lola", 3, "GermanShepard")

new_dog_3 = Dog.create_new_puppy("Lola", 0, "Labrador")
print(new_dog_3.__dict__)

# Point of classmethod
# - have access to class attributes
# - create new object depending on certain conditions