class Student :

    def __init__(self, name, level) :
        self.name = name
        self.level = level

    # instance method
    def get_info(self) :
        self.level = "First"
        print(self.name)

    @classmethod 
    def create (cls) :
        pass
        # create new object
        # access class attribute
    
    # method that doesnt use self, doesnt use cls
    # but you still want this method to be related to the whole
    # intead of creating it somewhere in the file
    @staticmethod
    def check_grade(grade):
        if grade > 80 :
            return "passing to next level"
        else :
             return "staying in the same level"
    

stu1 = Student("John", "Junior")
print(Student.check_grade(89)) #passing to next level