# Lise
#   12 h 26
# Exercise 2
# Create a Manager class, that inherits from the Employee class With the attributes : firstname, lastname, adress, age, job is manager as default, salary is 45000 by default, list of employees empty by default
# Create 1 manager object and display his attribute
# Brad Pitt 50 years old
# Add those methods to the class
# add_new_employee(self, new_employee) : adds the new employee object to the list of employees
# show_employees(self) : show the fullnames of all the employees under the manager
